import React from 'react'

export default function Contactus() {
  return (
    <div>
      <h1>this is contact us page_section</h1>
    </div>
  )
}
